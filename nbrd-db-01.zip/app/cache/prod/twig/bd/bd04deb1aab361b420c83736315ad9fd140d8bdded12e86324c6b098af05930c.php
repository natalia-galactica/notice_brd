<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* CodersLabBundle:Default:index.html.twig */
class __TwigTemplate_abd9832f38be5fbbece63ae2ac885738fd9e6dd5f5e7d10fed9c9012e752f2fc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<html>
<head>
<title> Tablica Ogłoszeń </title>
<style>
      html {
        font-size:16px;

      }

      div {
        background-color:#000080;
        padding:1em;
        font-size:1.3em;
      }
    </style
</head>
<body>
<center><h1>Tablica Ogłoszeń</h1></center>
<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css\" integrity=\"sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ\" crossorigin=\"anonymous\">
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js\" integrity=\"sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn\" crossorigin=\"anonymous\"></script>
<br>
<br><br>
<center>
\t<a href=\"/ad/\">-> Ogłoszenia</a>
\t<br>
\t<a href=\"/ad/addAd\"> ->Dodaj Ogłoszenie</a>
\t<br>
\t<a href=\"/login\">->Logowanie</a>
\t<br>
\t<a href=\"/register\">->Rejestracja</a>
\t<br>
</center>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "CodersLabBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "CodersLabBundle:Default:index.html.twig", "C:\\xampp\\htdocs\\symfony\\notice_board-master\\src\\CodersLabBundle/Resources/views/Default/index.html.twig");
    }
}
